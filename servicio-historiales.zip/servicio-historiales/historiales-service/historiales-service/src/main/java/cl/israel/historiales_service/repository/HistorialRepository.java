package cl.israel.historiales_service.repository;

import cl.israel.historiales_service.model.Historiales;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface HistorialRepository extends JpaRepository<Historiales, Long>{

    List<Historiales> findByNombreMascota(String nombreMascota);
    
    List<Historiales> findByNombreDoctor(String nombreDoctor);
    
    List<Historiales> findByFechaVisita(LocalDate fechaVisita);
    
    List<Historiales> findByFechaVisitaBetween(LocalDate fechaInicio, LocalDate fechaFin);
    
    List<Historiales> findByNombreMascotaAndNombreDoctor(String nombreMascota, String nombreDoctor);
    
    List<Historiales> findByDiagnosticoContaining(String diagnostico);

}
