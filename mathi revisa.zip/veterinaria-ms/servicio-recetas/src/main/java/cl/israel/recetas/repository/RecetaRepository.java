package cl.israel.recetas.repository;

import cl.israel.recetas.model.Receta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface RecetaRepository extends JpaRepository<Receta, Long> {
    
    // Buscar recetas por ID de historial
    List<Receta> findByIdHistorial(Long idHistorial);
    
    // Buscar recetas por ID de mascota
    List<Receta> findByIdMascota(Long idMascota);
    
    // Buscar recetas por medicamento
    List<Receta> findByMedicamento(String medicamento);
    
    // Buscar recetas por fecha de emisión
    List<Receta> findByFechaEmision(LocalDate fechaEmision);
    
    // Buscar recetas entre fechas
    List<Receta> findByFechaEmisionBetween(LocalDate startDate, LocalDate endDate);
}