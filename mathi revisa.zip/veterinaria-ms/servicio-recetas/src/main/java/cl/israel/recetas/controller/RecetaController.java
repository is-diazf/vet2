package cl.israel.recetas.controller;

import cl.israel.recetas.model.Receta;
import cl.israel.recetas.service.RecetaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/recetas")
@RequiredArgsConstructor
public class RecetaController {

    private final RecetaService recetaService;

    @PostMapping
    public ResponseEntity<Receta> crearReceta(@RequestBody Receta receta) {
        Receta nuevaReceta = recetaService.crearReceta(receta);
        return new ResponseEntity<>(nuevaReceta, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Receta>> listarRecetas() {
        return new ResponseEntity<>(recetaService.listarRecetas(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Receta> obtenerReceta(@PathVariable Long id) {
        Receta receta = recetaService.obtenerPorId(id);
        return new ResponseEntity<>(receta, HttpStatus.OK);
    }

    @GetMapping("/mascota/{idMascota}")
    public ResponseEntity<List<Receta>> obtenerPorMascota(@PathVariable Long idMascota) {
        return new ResponseEntity<>(recetaService.obtenerPorIdMascota(idMascota), HttpStatus.OK);
    }

    @GetMapping("/historial/{idHistorial}")
    public ResponseEntity<List<Receta>> obtenerPorHistorial(@PathVariable Long idHistorial) {
        return new ResponseEntity<>(recetaService.obtenerPorIdHistorial(idHistorial), HttpStatus.OK);
    }

    @GetMapping("/medicamento/{medicamento}")
    public ResponseEntity<List<Receta>> obtenerPorMedicamento(@PathVariable String medicamento) {
        return new ResponseEntity<>(recetaService.obtenerPorMedicamento(medicamento), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReceta(@PathVariable Long id) {
        recetaService.eliminarReceta(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}