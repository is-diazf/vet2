package cl.israel.recetas.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "recetas")
public class Receta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_historial", nullable = false)
    private Long idHistorial;

    @Column(name = "id_mascota", nullable = false)
    private Long idMascota;

    @Column(nullable = false, length = 50)
    private String medicamento;

    @Column(length = 100)
    private String dosis;

    @Column(name = "duracion_dias")
    private Integer duracionDias;

    @Column(columnDefinition = "TEXT")
    private String indicaciones;

    @Column(name = "fecha_emision", nullable = false)
    private LocalDate fechaEmision;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;
}