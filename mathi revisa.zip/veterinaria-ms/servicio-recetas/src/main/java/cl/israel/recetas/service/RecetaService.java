package cl.israel.recetas.service;

import cl.israel.recetas.model.Receta;
import cl.israel.recetas.repository.RecetaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RecetaService {

    private final RecetaRepository recetaRepository;

    public Receta crearReceta(Receta receta) {
        receta.setFechaEmision(LocalDate.now());
        receta.setFechaCreacion(LocalDateTime.now());
        return recetaRepository.save(receta);
    }

    public List<Receta> listarRecetas() {
        return recetaRepository.findAll();
    }

    public Receta obtenerPorId(Long id) {
        return recetaRepository.findById(id).orElse(null);
    }

    public List<Receta> obtenerPorIdMascota(Long idMascota) {
        return recetaRepository.findByIdMascota(idMascota);
    }

    public List<Receta> obtenerPorIdHistorial(Long idHistorial) {
        return recetaRepository.findByIdHistorial(idHistorial);
    }

    public List<Receta> obtenerPorMedicamento(String medicamento) {
        return recetaRepository.findByMedicamento(medicamento);
    }

    public void eliminarReceta(Long id) {
        recetaRepository.deleteById(id);
    }
}