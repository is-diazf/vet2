INSERT INTO mascotas (nombre, raza, fecha_nacimiento_mascota) VALUES 
('Firulais', 'Labrador', '2020-05-15'),
('Luna', 'Pastor Alemán', '2021-03-10'),
('Max', 'Golden', '2019-08-22');