USE db_mascotas;
CREATE TABLE IF NOT EXISTS mascotas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    raza VARCHAR(20) NOT NULL,
    fecha_nacimiento_mascota DATE
);