package veterinary_services.dto;

import lombok.Data;

@Data
public class VeterinariaRequestDTO {

    private String nombre;
    private String direccion;
    private String telefono;
}