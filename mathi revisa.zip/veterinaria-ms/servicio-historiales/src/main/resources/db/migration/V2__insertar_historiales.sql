INSERT INTO historiales (nombre_mascota, nombre_doctor, fecha_visita, diagnostico) VALUES 
('Firulais', 'Dr. Juan Pérez', '2026-05-20', 'Vacunación antirrábica'),
('Misi', 'Dra. María López', '2026-05-21', 'Chequeo general'),
('Luna', 'Dr. Carlos Gómez', '2026-05-22', 'Desparasitación'),
('Max', 'Dr. Juan Pérez', '2026-05-23', 'Infección respiratoria'),
('Rocky', 'Dra. María López', '2026-05-24', 'Alergia en la piel'),
('Bella', 'Dr. Carlos Gómez', '2026-05-25', 'Revisión dental');

