package cl.israel.citas.dto;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class CitaResponseDTO {
    private Long id;
    private Long idVeterinario;
    private String nombreMascota;
    private String razaMascota;
    private String nombreDueño;
    private String telefonoDueño;
    private LocalDate fechaCita;
    private LocalTime horaCita;
    private String motivoCita;
}