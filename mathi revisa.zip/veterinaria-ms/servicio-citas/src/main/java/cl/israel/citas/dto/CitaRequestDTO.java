package cl.israel.citas.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class CitaRequestDTO {

    @NotNull(message = "El ID de la veterinaria es obligatorio")
    private Long idVeterinario;

    @NotBlank(message = "El nombre de la mascota es obligatorio")
    private String nombreMascota;

    private String razaMascota;

    @NotBlank(message = "El nombre del dueño es obligatorio")
    private String nombreDueño;

    private String telefonoDueño;

    @NotNull(message = "La fecha de la cita es obligatoria")
    private LocalDate fechaCita;

    @NotNull(message = "La hora de la cita es obligatoria")
    private LocalTime horaCita;

    private String motivoCita;
}