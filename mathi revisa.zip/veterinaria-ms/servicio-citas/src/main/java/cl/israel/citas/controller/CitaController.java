package cl.israel.citas.controller;

import cl.israel.citas.model.Citas;
import cl.israel.citas.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/citas")
@RequiredArgsConstructor
public class CitaController {

    private final CitaService citaService;
    @PostMapping
    public ResponseEntity<Citas> crearCita(@RequestBody Citas cita) {
        Citas nuevaCita = citaService.crearCita(cita);
        return new ResponseEntity<>(nuevaCita, HttpStatus.CREATED);
    }

}
