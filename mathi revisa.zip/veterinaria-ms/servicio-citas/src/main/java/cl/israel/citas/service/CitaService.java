package cl.israel.citas.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import cl.israel.citas.model.Citas;
import cl.israel.citas.repository.CitaRepository;
import cl.israel.citas.client.*;
import cl.israel.citas.dto.*;

@Service
@RequiredArgsConstructor
public class CitaService {

    private final CitaRepository citaRepository;
    private final VeterinarioClient veterinarioClient;

    public Citas crearCita(Citas cita) {
        // Validar que el veterinario exista
        VeterinarioDTO veterinario = veterinarioClient.obtenerVeterinario(cita.getIdVeterinario());
        if (veterinario == null) {
            throw new RuntimeException("Veterinario no encontrado");
        }
        System.out.println("Veterinario encontrado: " + veterinario.getNombre());
     
        return citaRepository.save(cita);
    }
}
