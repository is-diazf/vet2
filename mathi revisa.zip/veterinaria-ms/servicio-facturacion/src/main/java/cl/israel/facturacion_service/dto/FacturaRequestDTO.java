package cl.israel.facturacion_service.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class FacturaRequestDTO {

    @NotNull(message = "El ID de la cita es obligatorio")
    private Long idCita;

    @NotNull(message = "El monto total es obligatorio")
    @Positive(message = "El monto total debe ser mayor a 0")
    private Double montoTotal;

    private String metodoPago;  // EFECTIVO, TARJETA, TRANSFERENCIA
}