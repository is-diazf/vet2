package cl.israel.facturacion_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "facturas")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "El ID de la cita es obligatorio")
    @Column(name = "id_cita", nullable = false)
    private Long idCita;

    @NotNull(message = "El monto total es obligatorio")
    @Positive(message = "El monto total debe ser mayor a 0")
    @Column(name = "monto_total", nullable = false)
    private Double montoTotal;

    @Column(name = "fecha_emision", nullable = false)
    private LocalDateTime fechaEmision;

    @Column(length = 20)
    private String estado;  // PENDIENTE, PAGADA, ANULADA

    @Column(length = 30)
    private String metodoPago;  // EFECTIVO, TARJETA, TRANSFERENCIA
}