package cl.israel.facturacion_service.repository;

import cl.israel.facturacion_service.model.Factura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {

    List<Factura> findByIdCita(Long idCita);      // ← findBy (sin Id extra)

    List<Factura> findByEstado(String estado);    // ← findByEstado, no findByIdEstado

    List<Factura> findByMetodoPago(String metodoPago);  // ← findByMetodoPago
}