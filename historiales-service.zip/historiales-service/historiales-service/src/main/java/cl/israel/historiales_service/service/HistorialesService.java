package cl.israel.historiales_service.service;

import cl.israel.historiales_service.dto.HistorialesResponseDTO;
import cl.israel.historiales_service.model.Historiales;
import cl.israel.historiales_service.repository.HistorialRepository;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class HistorialesService {

    private final HistorialRepository historialRepository;

    public HistorialesResponseDTO obtenerPorId(Long id) {
        Historiales historial = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Historial no encontrado con id: " + id));
        return mapearDto(historial);
    }

    // Obtener todos los historiales
    public List<HistorialesResponseDTO> obtenerTodos() {
        List<Historiales> historiales = historialRepository.findAll();
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

    // Obtener historiales por nombre de mascota
    public List<HistorialesResponseDTO> obtenerPorMascota(String nombreMascota) {
        List<Historiales> historiales = historialRepository.findByNombreMascota(nombreMascota);
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

    public List<HistorialesResponseDTO> obtenerPorDoctor(String nombreDoctor) {
        List<Historiales> historiales = historialRepository.findByNombreDoctor(nombreDoctor);
        return historiales.stream()
                .map(this::mapearDto)
                .collect(Collectors.toList());
    }

     public HistorialesResponseDTO guardar(Historiales historial) {
        Historiales historialGuardado = historialRepository.save(historial);
        return mapearDto(historialGuardado);
    }

    // Actualizar un historial existente
    public HistorialesResponseDTO actualizar(Long id, Historiales detallesHistorial) {
        Historiales historialExistente = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Historial no encontrado con ese id: " + id));

        historialExistente.setNombreMascota(detallesHistorial.getNombreMascota());
        historialExistente.setNombreDoctor(detallesHistorial.getNombreDoctor());
        historialExistente.setFechaVisita(detallesHistorial.getFechaVisita());
        historialExistente.setDiagnostico(detallesHistorial.getDiagnostico());

        Historiales historialActualizado = historialRepository.save(historialExistente);
        return mapearDto(historialActualizado);
    }

    public void eliminar(Long id) {
        Historiales historial = historialRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("No hay historial con ese id: " + id));
        historialRepository.delete(historial);
    }

     private HistorialesResponseDTO mapearDto(Historiales historial) {
        HistorialesResponseDTO dto = new HistorialesResponseDTO();
        dto.setId(historial.getId());
        dto.setNombreMascota(historial.getNombreMascota());
        dto.setNombreDoctor(historial.getNombreDoctor());
        dto.setFechaVisita(historial.getFechaVisita());
        dto.setDiagnostico(historial.getDiagnostico());
        return dto;
    }


}
