package cl.israel.historiales_service.model;

import java.time.LocalDate;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "historiales")
@Entity
public class Historiales {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre_mascota")
    @NotBlank(message = "por favor ingrese el nombre de la mascota")
    private String nombreMascota;

    @Column(name = "nombre_doctor")
    @NotBlank(message = "ingrese el nombre del doctor asignado")
    private String nombreDoctor;

    @Column(name = "fecha_visita")
    @NotNull
    private LocalDate fechaVisita;
    
    @Column(length = 500)
    @NotBlank(message = "ingrese el diagnostico")
    private String diagnostico;

}
