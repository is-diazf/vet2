package cl.israel.historiales_service.controller;

import cl.israel.historiales_service.dto.HistorialesResponseDTO;
import cl.israel.historiales_service.model.Historiales;
import cl.israel.historiales_service.service.HistorialesService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/historiales")
@RequiredArgsConstructor
public class HistorialesController {

    private final HistorialesService historialesService;

    @GetMapping
    public ResponseEntity<List<HistorialesResponseDTO>> listarHistoriales() {
        List<HistorialesResponseDTO> historiales = historialesService.obtenerTodos();
        return ResponseEntity.ok(historiales);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistorialesResponseDTO> obtenerHistorial(@PathVariable Long id) {
        HistorialesResponseDTO historial = historialesService.obtenerPorId(id);
        return ResponseEntity.ok(historial);
    }

    @GetMapping("/mascota/{nombreMascota}")
    public ResponseEntity<List<HistorialesResponseDTO>> listarPorMascota(@PathVariable String nombreMascota) {
        List<HistorialesResponseDTO> historiales = historialesService.obtenerPorMascota(nombreMascota);
        return ResponseEntity.ok(historiales);
    }

    @GetMapping("/doctor/{nombreDoctor}")
    public ResponseEntity<List<HistorialesResponseDTO>> listarPorDoctor(@PathVariable String nombreDoctor) {
        List<HistorialesResponseDTO> historiales = historialesService.obtenerPorDoctor(nombreDoctor);
        return ResponseEntity.ok(historiales);
    }

    @PostMapping
    public ResponseEntity<HistorialesResponseDTO> guardarHistorial(@RequestBody Historiales historiales) {
        HistorialesResponseDTO nuevoHistorial = historialesService.guardar(historiales);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoHistorial);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HistorialesResponseDTO> actualizarHistorial(
            @PathVariable Long id,
            @RequestBody Historiales historiales) {
        HistorialesResponseDTO historialActualizado = historialesService.actualizar(id, historiales);
        return ResponseEntity.ok(historialActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarHistorial(@PathVariable Long id) {
        historialesService.eliminar(id);
        return ResponseEntity.noContent().build();
    }


}
