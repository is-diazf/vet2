package cl.israel.historiales_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistorialesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
