package cl.israel.historiales_service.repository;

import cl.israel.historiales_service.model.Historiales;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface HistorialRepository extends JpaRepository<Historiales, Long>{


}
